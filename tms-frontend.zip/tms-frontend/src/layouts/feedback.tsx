import React from 'react'

const FeedbackLayout = ({ children }: { children: React.ReactElement }) => {
    return children;
}

export default FeedbackLayout;