import React from 'react';

const TableAnt = () => {
    return (
        <div>TableAnt</div>
    )
}

export default TableAnt;