import React from 'react'

const CalendarTab = () => {
    return (
        <div>Calendar</div>
    )
}

export default CalendarTab