import React from 'react';
import styles from '@/styles/employee/TE.module.scss';

const Report = () => {
    return (
        <div className={styles.containerReport}>
            Report
        </div>
    )
}

export default Report;