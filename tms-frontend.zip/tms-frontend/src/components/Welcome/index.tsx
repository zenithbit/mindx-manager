function Welcome() {
    return (
        <>
            <p><b>Welcome to MindX TMS</b></p>
        </>
    )
}

export default Welcome;
