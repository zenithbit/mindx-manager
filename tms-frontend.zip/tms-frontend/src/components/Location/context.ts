import { createContextToolBar } from "../Tabs/ToolBar/config";

const ManagerLocationContext = createContextToolBar();
export default ManagerLocationContext;