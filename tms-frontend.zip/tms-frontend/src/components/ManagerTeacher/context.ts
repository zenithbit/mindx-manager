import { createContextToolBar } from "../Tabs/ToolBar/config";

const ManagerTeacherContext = createContextToolBar();
export default ManagerTeacherContext;