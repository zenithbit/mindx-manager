import React from 'react';
import styles from '@/styles/class/DetailClass.module.scss';

const Syllabus = () => {
    return (
        <div className={styles.syllabusDetailClass}>Syllabus</div>
    )
}

export default Syllabus;