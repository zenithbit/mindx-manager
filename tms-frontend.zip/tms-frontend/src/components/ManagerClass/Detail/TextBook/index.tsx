import React from 'react';
import styles from '@/styles/class/DetailClass.module.scss';

const TextBook = () => {
    return (
        <div className={styles.textBookDetailClass}>TextBook</div>
    )
}

export default TextBook;