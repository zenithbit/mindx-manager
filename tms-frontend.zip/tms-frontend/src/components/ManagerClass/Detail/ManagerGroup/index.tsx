import React from 'react';
import styles from '@/styles/class/DetailClass.module.scss';

const ManagerGroup = () => {
    return (
        <div className={styles.managerGroupDetailClass}>ManagerGroup</div>
    )
}

export default ManagerGroup;