const data = [
    {
        date: new Date(),
        studentName: 'Trần Đăng Khoa',
        groupNumber: {
            mentor: 'Nguyễn Văn Cường',
            groupNumber: 1,
            location: 'HĐT'
        },
        pointST: 4,
        pointMT: 3,
        docDetail: 'Thôi k còn gì phải bàn cãi, tuyệt vời siêu phẩm!'
    }
]
export default data;