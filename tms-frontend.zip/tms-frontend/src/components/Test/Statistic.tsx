import React from 'react';
import styles from '@/styles/Test.module.scss';


const Statistic = () => {
    return (
        <div>Statistic</div>
    )
}

export default Statistic;