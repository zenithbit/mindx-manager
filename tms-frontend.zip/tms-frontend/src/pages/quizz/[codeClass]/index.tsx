import React from 'react';
import Teacher from '@/components/Test/Teacher';

const TeacherQuizz = () => {
    return (
        <Teacher />
    )
}

export default TeacherQuizz;
TeacherQuizz.isPublic = true;