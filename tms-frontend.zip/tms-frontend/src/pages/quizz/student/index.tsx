import React from 'react';
import StudentQuizzUI from '@/components/Test/Student';

const StudentQuizz = () => {
    return (
        <StudentQuizzUI />
    )
}

export default StudentQuizz;
StudentQuizz.isPublic = true;