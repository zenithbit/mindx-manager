import React from 'react';
import FeedbackClautid from '@/components/Candidate/FeedbackClautid';

const FeedbackClautidPage = () => {
    return (
        <FeedbackClautid />
    )
}

export default FeedbackClautidPage;
FeedbackClautidPage.isPublic = true;