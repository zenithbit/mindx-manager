import React from 'react';
import ListClassRunning from '@/components/Candidate/ListClassRunning';

const ClassRunning = () => {
    return (
        <ListClassRunning />
    )
}

export default ClassRunning;
ClassRunning.isPublic = true;