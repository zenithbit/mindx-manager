import React from 'react';
import Candidate from '@/components/Candidate';

const CandidatePage = () => {
    return (
        <Candidate />
    )
}

export default CandidatePage;
CandidatePage.isPublic = true;