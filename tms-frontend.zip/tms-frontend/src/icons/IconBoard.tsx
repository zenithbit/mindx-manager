import React, { HTMLAttributes } from 'react'

const IconBoard = (props: HTMLAttributes<HTMLElement | any>) => {
    return (
        <svg {...props} width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15.1199 4.50684L12.8733 13.5269C12.7133 14.2002 12.1133 14.6668 11.4199 14.6668H2.65992C1.65326 14.6668 0.933267 13.6801 1.23327 12.7135L4.03993 3.7002C4.23326 3.07353 4.81327 2.64014 5.4666 2.64014H13.6666C14.2999 2.64014 14.8266 3.02681 15.0466 3.56014C15.1733 3.84681 15.1999 4.1735 15.1199 4.50684Z" stroke="#222222" strokeWidth="1.5" strokeMiterlimit="10" />
            <path d="M11.1667 14.6667H14.3534C15.2134 14.6667 15.8867 13.94 15.8267 13.08L15.1667 4" stroke="#222222" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M6.95337 4.2535L7.64671 1.37354" stroke="#222222" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M11.4199 4.26001L12.0466 1.3667" stroke="#222222" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M5.6333 8H10.9666" stroke="#222222" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M4.9668 10.6665H10.3001" stroke="#222222" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
        </svg>

    )
}

export default IconBoard;